﻿namespace CollectionHierarchy.Interfaces
{
    public interface IRemoveable<T>
    {
        T Remove();
    }
}
