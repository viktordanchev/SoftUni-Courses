﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAddable<T>
    {
        int Add(T item);
    }
}
