﻿namespace Telephony.Interfaces
{
    public interface IStationaryPhone
    {
        void Dialing(string phoneNumber);
    }
}
