﻿namespace Telephony.Interfaces
{
    public interface ISmartphone 
    {
        void Calling(string phoneNumber);
        void Browsing(string website);
    }
}
