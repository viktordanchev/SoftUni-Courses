﻿namespace WildFarm.Interfaces
{
    public interface IMammal
    {
        string LivingRegion { get; }    
    }
}
