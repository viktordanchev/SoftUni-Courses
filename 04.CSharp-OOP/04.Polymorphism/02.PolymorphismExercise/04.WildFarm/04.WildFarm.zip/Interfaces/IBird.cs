﻿namespace WildFarm.Interfaces
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
