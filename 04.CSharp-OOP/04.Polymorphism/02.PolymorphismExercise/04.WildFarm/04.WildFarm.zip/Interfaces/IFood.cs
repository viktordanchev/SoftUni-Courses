﻿namespace WildFarm.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
