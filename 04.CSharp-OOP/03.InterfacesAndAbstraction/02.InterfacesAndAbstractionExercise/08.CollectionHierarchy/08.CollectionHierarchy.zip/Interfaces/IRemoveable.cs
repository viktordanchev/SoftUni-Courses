﻿namespace _08.CollectionHierarchy.Interfaces
{
    public interface IRemoveable<T>
    {
        T Remove();
    }
}
