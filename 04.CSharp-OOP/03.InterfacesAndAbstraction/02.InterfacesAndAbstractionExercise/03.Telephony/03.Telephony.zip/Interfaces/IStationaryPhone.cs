﻿namespace _03.Telephony.Interfaces
{
    public interface IStationaryPhone
    {
        void Dialing(string phoneNumber);
    }
}
