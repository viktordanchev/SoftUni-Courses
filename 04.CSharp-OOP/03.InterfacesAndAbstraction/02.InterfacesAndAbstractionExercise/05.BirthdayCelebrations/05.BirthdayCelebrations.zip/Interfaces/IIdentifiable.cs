﻿namespace _05.BirthdayCelebrations.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
