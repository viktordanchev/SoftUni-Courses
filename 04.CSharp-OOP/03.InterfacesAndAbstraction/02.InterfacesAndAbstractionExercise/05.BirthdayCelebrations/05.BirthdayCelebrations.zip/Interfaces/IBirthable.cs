﻿namespace _05.BirthdayCelebrations.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
