﻿namespace BirthdayCelebrations.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
