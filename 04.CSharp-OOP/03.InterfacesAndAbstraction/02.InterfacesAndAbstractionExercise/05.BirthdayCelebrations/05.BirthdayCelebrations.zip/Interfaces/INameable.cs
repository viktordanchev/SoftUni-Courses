﻿namespace _05.BirthdayCelebrations.Interfaces
{
    public interface INameable
    {
        string Name { get; }
    }
}
