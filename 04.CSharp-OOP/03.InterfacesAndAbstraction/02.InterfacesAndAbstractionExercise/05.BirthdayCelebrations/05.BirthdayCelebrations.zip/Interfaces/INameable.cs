﻿namespace BirthdayCelebrations.Interfaces
{
    public interface INameable
    {
        string Name { get; }
    }
}
