﻿namespace FoodShortage.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
