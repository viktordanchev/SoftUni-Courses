﻿namespace FoodShortage.Interfaces
{
    public interface INameable
    {
        string Name { get; }
    }
}
