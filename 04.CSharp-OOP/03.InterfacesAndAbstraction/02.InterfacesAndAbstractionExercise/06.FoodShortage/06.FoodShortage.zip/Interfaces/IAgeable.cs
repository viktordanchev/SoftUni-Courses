﻿namespace FoodShortage.Interfaces
{
    public interface IAgeable
    {
        int Age { get; }
    }
}
