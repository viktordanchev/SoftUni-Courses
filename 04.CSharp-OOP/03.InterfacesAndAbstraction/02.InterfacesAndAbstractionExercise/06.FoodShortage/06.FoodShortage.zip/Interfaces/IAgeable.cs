﻿namespace _06.FoodShortage.Interfaces
{
    public interface IAgeable
    {
        int Age { get; }
    }
}
