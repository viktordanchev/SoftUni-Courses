﻿namespace SpaceStation.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
