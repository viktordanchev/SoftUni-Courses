﻿using System;

namespace _06.GenericCountMethodDouble
{
    internal class Box<T> where T : IComparable<T>
    {
        public T BoxValue { get; set; }

        public override string ToString()
        {
            return $"{BoxValue.GetType()}: {BoxValue}";
        }

        //public int CompareTo(T other)
        //{
        //    return BoxValue.CompareTo(other);
        //}
    }
}