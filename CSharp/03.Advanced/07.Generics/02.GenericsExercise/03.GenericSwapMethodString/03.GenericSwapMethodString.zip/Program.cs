﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03.GenericSwapMethodString
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Box<string>> list = new List<Box<string>>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Box<string> box = new Box<string>();

                box.BoxValue = Console.ReadLine();

                list.Add(box);
            }

            int[] swapCommands = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();

            GenericMethod(list, swapCommands);

            foreach (var item in list)
            {
                Console.WriteLine(item.ToString());
            }
        }

        static void GenericMethod<T>(List<T> list, int[] swapCommands)
        {
            int firstIndex = swapCommands[0];
            int secondIndex = swapCommands[1];

            T currElement = list[firstIndex];
            list[firstIndex] = list[secondIndex];
            list[secondIndex] = currElement;
        }
    }
}