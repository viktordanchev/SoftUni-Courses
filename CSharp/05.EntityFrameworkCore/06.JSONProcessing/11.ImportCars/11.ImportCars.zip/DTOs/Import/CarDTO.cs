﻿namespace CarDealer.DTOs.Import
{
    public class CarDTO
    {
        public string Make { get; set; } = null!;

        public string Model { get; set; } = null!;

        public long TraveledDistance { get; set; }
    }
}
