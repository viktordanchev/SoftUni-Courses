﻿namespace Medicines.Data.Models.Enums
{
    public enum Gender
    {
        Male,
        Female
    }
}
