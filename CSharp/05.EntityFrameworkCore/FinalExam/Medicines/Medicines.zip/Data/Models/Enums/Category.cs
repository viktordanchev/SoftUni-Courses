﻿namespace Medicines.Data.Models.Enums
{
    public enum Category
    {
        Analgesic,
        Antibiotic,
        Antiseptic,
        Sedative,
        Vaccine
    }
}
