﻿namespace Medicines.Data.Models.Enums
{
    public enum AgeGroup
    {
        Child,
        Adult,
        Senior
    }
}
