﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=VIKTOR-PC\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}
