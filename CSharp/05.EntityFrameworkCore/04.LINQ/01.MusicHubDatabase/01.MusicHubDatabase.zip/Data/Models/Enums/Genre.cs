﻿namespace _01.MusicHubDatabase.Data.Models.Enums
{
    public enum Genre
    {
        Blues,
        Rap,
        PopMusic,
        Rock,
        Jazz
    }
}
