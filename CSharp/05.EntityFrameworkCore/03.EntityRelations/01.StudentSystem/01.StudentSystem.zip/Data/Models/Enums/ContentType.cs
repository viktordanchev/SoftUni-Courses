﻿namespace _01.StudentSystem.Data.Models.Enums
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}
