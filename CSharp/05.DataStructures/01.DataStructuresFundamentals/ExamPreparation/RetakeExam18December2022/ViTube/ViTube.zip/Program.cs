﻿using System;
using System.Linq;

namespace Exam.ViTube
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var n = new ViTubeRepository();

            Video v = new Video("3", "new", 3.45, 300, 30, 10);
            Video v1 = new Video("32", "new2", 2.45, 3420, 30, 120);
            Video v2 = new Video("34", "new3", 3.15, 3420, 364, 104);

            n.PostVideo(v);
            n.PostVideo(v1);
            n.PostVideo(v2);

            User u = new User("1", "asen");
            User u1 = new User("2", "mitko");
            User u2 = new User("3", "dimo");

            n.RegisterUser(u);
            n.RegisterUser(u1);
            n.RegisterUser(u2);

            n.WatchVideo(u, v);
            n.LikeVideo(u1, v1);
            n.DislikeVideo(u2, v2);
            n.DislikeVideo(u1, v2);

            Console.WriteLine(string.Join(" ", n.GetUsersByActivityThenByName().Select(v => v.Username)));
        }
    }
}
