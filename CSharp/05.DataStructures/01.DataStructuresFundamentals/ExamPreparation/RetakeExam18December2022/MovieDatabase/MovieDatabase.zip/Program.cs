﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Exam.MovieDatabase
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var n = new MovieDatabase();

            var m1 = new Movie("1", 123, "no1", 5.3, 233333);
            var m2 = new Movie("2", 153, "no2", 4.3, 23333);
            var m3 = new Movie("3", 173, "no3", 2.3, 2333);

            var a1 = new Actor("1", "asen", 53);
            var a2 = new Actor("2", "mitko", 43);
            var a3 = new Actor("3", "dimo", 23);

            n.AddActor(a1);
            n.AddActor(a2);
            n.AddActor(a3);

            n.AddMovie(a1, m1);
            n.AddMovie(a2, m2);
            n.AddMovie(a3, m2);

            Console.WriteLine(string.Join(", ", n.GetAllMovies().Select(v => v.Title)));
        }
    }
}
